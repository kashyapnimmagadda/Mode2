import { Component } from '@angular/core';
import { Employee } from './employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'assignment';
  favoriteMovie: string ="Lord of the Rings";
  emp:Employee = {
    id:3,
    name:"John",
    salary:10000,
    permanent:true,
    department:{
      departmentId:1,
      depatmentName:"Payroll"
    },
    skills:
    [
      {skill_id:1,skill_name:"HTML"},
      {skill_id:2,skill_name:"CSS"},
      {skill_id:3,skill_name:"JavaScript"}
    ],
    dateOfBirth: new Date('12/31/2000')
  }
} 
