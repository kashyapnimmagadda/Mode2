export interface skill{
    skill_id:number;
    skill_name:string;
    //skillss:[number,string];
}