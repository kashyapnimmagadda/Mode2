export interface department{
    departmentId:number;
    depatmentName:string;
}